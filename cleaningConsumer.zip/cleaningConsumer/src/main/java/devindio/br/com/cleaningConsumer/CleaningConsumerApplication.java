package devindio.br.com.cleaningConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CleaningConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CleaningConsumerApplication.class, args);
	}

}
