package devindio.br.com.cleaningConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CleaningConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
